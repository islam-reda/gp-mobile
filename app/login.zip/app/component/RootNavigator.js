import Login from './login';
import Home from './Home';
import Signup from './Signup';
import Stores from './Stores';
import Splash from '../common/Splash';
import Location from './Location.js';
import Cart from './Cart.js';
import Profile from './Profile.js';
import {StackNavigator} from 'react-navigation';
import Storetabnavigation from './Storetabnavigation.js'
const RootNavigator = StackNavigator({
  Splash: {
    screen: Splash,
    navigationOptions: ({
      header: null,
    }),
  },
  Profile: {
    screen: Profile,
    navigationOptions: ({
      title : 'My profile',
    }),
  },

  Location: {
    screen: Storetabnavigation,
    navigationOptions: ({
      title : 'Map view',
    }),
  },
  Cart: {
    screen: Cart,
    navigationOptions: ({
      title : 'Dejavu.shoes',
    }),
  },

  Loginpage: {
    screen: Login,
    navigationOptions: ({
      title : 'none',
      header: null,
      // headerMode : none,
    }),
  },
  Home: {
    screen: Home,
    navigationOptions: ({
      title : 'none',
      header: null,
      // headerMode : none,
    }),
  },
  Signup: {
    screen: Signup,
    navigationOptions: ({
      title : 'Register account',
      // headerMode : none,
    }),
  },
  Stores: {
    screen: Stores,
    navigationOptions: ({
      title : 'Stores',
      // headerMode : none,
    }),
  }
});
export default RootNavigator;
