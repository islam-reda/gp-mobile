export const LOGIN_ATTEMPT = 'login_attempt';
export const LOGIN_SUCCESS = 'login_sucess';
export const LOGIN_FAILED = 'login_failed';
export const LOGIN_CODESUCCESS = 'login_codesucess';
export const LOGIN_CODEFAILED = 'login_codefailed';
export const VERFY_USERSUCCESS = 'verfy_user_success';
export const VERFY_USERFAILED = 'verfy_user_failed';
//redeem
export const GET_REDEEM_ATTEMP = 'get_redeem_attemp';
export const GET_REDEEM_ATTEMP_SUCCESS = 'get_redeem_attemp_success';
export const GET_REDEEM_ATTEMP_FAILED = 'get_redeem_attemp_failed';
//voucher
export const GET_VOCHER_ATTEMP = 'get_voucher_attemp';
export const GET_VOCHER_ATTEMP_SUCCESS = 'get_voucher_attemp_success';
export const GET_VOCHER_ATTEMP_FAILED = 'get_voucher_attemp_failed';
//news
export const GET_NEWS_ATTEMP = 'get_news_attemp';
export const GET_NEWS_ATTEMP_SUCCESS = 'get_news_success';
export const GET_NEWS_ATTEMP_FAILED = 'get_news_failed';
//profile
export const GET_PROFILE_ATTEMP = 'get_profile_attemp';
export const GET_PROFILE_ATTEMP_SUCCESS = 'get_profile_success';
export const GET_PROFILE_ATTEMP_FAILED = 'get_profile_failed';
//get CATEGORIES
export const GET_CATEGORIES_ATTEMP = 'get_categories_attemp';
export const GET_CATEGORIES_ATTEMP_SUCCESS = 'get_categories_success';
export const GET_CATEGORIES_ATTEMP_FAILED = 'get_categories_failed';
//get Product by Category
export const GET_CATEGORIES_PRODUCT_ATTEMP = 'get_categories_product_attemp';
export const GET_CATEGORIES_PRODUCT_ATTEMP_SUCCESS = 'get_categories_product_success';
export const GET_CATEGORIES_PRODUCT_ATTEMP_FAILED = 'get_categories_product_failed';
//get Single Product by Category
export const GET_SINGLE_PRODUCT_ATTEMP = 'get_single_product_attemp';
export const GET_SINGLE_PRODUCT_ATTEMP_SUCCESS = 'get_single_product_success';
export const GET_SINGLE_PRODUCT_ATTEMP_FAILED = 'get_single_product_failed';



export const REGISTER_ATTEMPT = 'register_attempt';
export const REGISTER_SUCCESS = 'register_success';
export const REGISTER_FAILED = 'register_failed';


export const GET_CLOSEST_STORE_ATTEMPT = 'get_closest_store_attemp';
export const GET_CLOSEST_STORE = 'get_closest_store';


// abram
export const GET_HOME_ATTEMP = 'get_home_attemp';
export const GET_HOME_ATTEMP_SUCCESS = 'get_home_attemp_success';
export const GET_HOME_ATTEMP_FAILED = 'get_home_attemp_failed';

export const SAVE_RATE_FAILED = 'save_rate_failed';


export const GET_PLACES_ATTEMP = 'get_places_attemp';
export const GET_PLACES_ATTEMP_SUCCESS = 'get_places_attemp_success';
export const GET_PLACES_ATTEMP_FAILED = 'get_places_attemp_failed';
export const SAVE_RATE_SUCCESS = 'save_rate_success';

