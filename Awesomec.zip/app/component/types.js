export const LOGIN_ATTEMPT = 'login_attempt';
export const LOGIN_SUCCESS = 'login_sucess';
export const LOGIN_FAILED = 'login_failed';
export const LOGIN_CODESUCCESS = 'login_codesucess';
export const LOGIN_CODEFAILED = 'login_codefailed';
export const VERFY_USERSUCCESS = 'verfy_user_success';
export const VERFY_USERFAILED = 'verfy_user_failed';
//redeem
export const GET_REDEEM_ATTEMP = 'get_redeem_attemp';
export const GET_REDEEM_ATTEMP_SUCCESS = 'get_redeem_attemp_success';
export const GET_REDEEM_ATTEMP_FAILED = 'get_redeem_attemp_failed';
//voucher
export const GET_VOCHER_ATTEMP = 'get_voucher_attemp';
export const GET_VOCHER_ATTEMP_SUCCESS = 'get_voucher_attemp_success';
export const GET_VOCHER_ATTEMP_FAILED = 'get_voucher_attemp_failed';
//news
export const GET_NEWS_ATTEMP = 'get_news_attemp';
export const GET_NEWS_ATTEMP_SUCCESS = 'get_news_success';
export const GET_NEWS_ATTEMP_FAILED = 'get_news_failed';


export const REGISTER_ATTEMPT = 'register_attempt';
export const REGISTER_SUCCESS = 'register_success';
export const REGISTER_FAILED = 'register_failed';



export const LOCATION_SERVICE = 'location';


export const GET_CLOSEST_STORE_ATTEMPT = 'get_closest_store_attemp';
export const GET_CLOSEST_STORE = 'get_closest_store';
